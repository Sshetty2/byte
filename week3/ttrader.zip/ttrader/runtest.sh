#! /bin/sh

python3 -m unittest tests/test*.py
